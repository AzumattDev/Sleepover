| `Version` | `Update Notes`                                                                                                                                                         |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.1.3     | - Update for Ashlands.                                                                                                                                                 |
| 1.1.2     | - Initial Release (continue from 1.1.1 of kinghfb's version. It was MIT and someone wanted it updated, happy to have someone other than me take this over permanently) |


His old Changelog (from GitHub):
=========

1.0.1
-----
* Added new texts for Swamp and Mountains changes
* Added new texts for new recipes

1.0.0
-----
* Update for Hearth and Home

0.9.2
-----
* Consolidated language files into one file to fix bug with ValheimLib and Jotunn only loading the first file in a directory for a mod.
* Reverted Jotunn dependency due to incompleteness.
* Fixed bad references for Eikthyr dream and runetable texts

0.9.1
-----
* Patch release to retarget for Jotunn over deprecated ValheimLib.
* Fixed typo.

0.9.0
-----
* Initial pre-release.
* Dreams and runestones texts.
* Thunderstore distribution metadata.


